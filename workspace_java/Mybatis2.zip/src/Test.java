import java.util.*;

import org.apache.ibatis.session.*;

public class Test {

	public static void main(String[] args) {
		SqlSession session = SqlMapClient.getSqlSession();
		
		List<Map<String, String>> list = session.selectList("Test.select");
		System.out.println(list);
		
	}

}
