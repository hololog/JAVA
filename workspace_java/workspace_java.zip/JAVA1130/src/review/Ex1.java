package review;

public class Ex1 {
	public static void main(String[] args) {
		
		// 문자와 문자열
		System.out.println("아이"+"티윌");
		System.out.println(1+1);
		System.out.println("1"+"1");
		
		// 이스케이프
		System.out.println("선생님이 말했다 \n\"아! 자바 재밋다!\"");
		
		// \t
		System.out.println("90\t80\t70");
		System.out.println("국어\t수학\t영어");
		
		System.out.println("=================================");
		int a;
		a=1;
		System.out.println(a+1);
		a=2;
		System.out.println(a+1);
		
		
		String name;
		name = "차동원";
		System.out.println(name);
		
		
		
	}
}



