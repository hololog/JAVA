
public class Ex4 {

	public static void main(String[] args) {
		/*
		 * 자바스크립트
		 * 
		 * 모당창을 통해 메세지를 출력 alert()
		 * 모달창을 통해 입력 받기 prompt()
		 * 모달창을 통해 예,아니오를 선택할 수 있는 함수 confirm()
		 * console창에서 데이터를 확인하는 함수 console.log()
		 * 새창을 여는 함수 window.open()
		 * 페이지 이동 location.href = ~~~~ , 문자열형태(""), http:// 가 붙어야함!
		 * 이전페이지 이동 history.back()
		 * 다음페이지 이동 history.forward()
		 * 특정 페이지 만큼 이전 또는 다음 페이지로 이동 history.go(숫자)
		 * 
		 * */
		
		/* 단답형 (14문제)
		 * 실습 (4문제) : 파일을 제출해야함! (소스코드 + console 캡처 파일 = 압축)
		 * 
		 * 
		 * */
		
		
		
	}

}
