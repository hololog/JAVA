package if_statement;

public class Ex4 {

	public static void main(String[] args) {
		
		/*
		 * if ~ else if ~ else 문
		 * 
		 * < 기본 문법 >
		 * if(조건식1){
		 * 
		 * } else if(조건식2) {
		 * 
		 * } else if(조건식3) {
		 * 
		 * } else {	// 생략가능
		 * 
		 * }
		 * 
		 * 
		 * */
		
		// 정수 num이 5보다 크다 or 5보다 작다 5와 같다 판별
		int num = 3;
		if(num > 5) {
			System.out.println("num이 5보다 크다!");
		} else if(num < 5) {
			System.out.println("num이 5보다 작다!");
		} else {
			System.out.println("num이 5와 같다");
		} 
		
		
		
		
		
		
		
		
	}

}
