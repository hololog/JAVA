package for_statement;

public class Test1 {

	public static void main(String[] args) {

		/*
		 * 구구단의 특정 단 출력
		 * 
		 * < 2단 >
		 * 2 * 1 = 2
		 * 2 * 2 = 4
		 * 2 * 3 = 6
		 * ...
		 * 2 * 9 = 18
		 * 
		 * */
		int dan=5;
		
		System.out.println("< 2단 >");
		System.out.println("2 * 1 = 2");
		System.out.println("2 * 2 = 4");
		System.out.println("2 * 3 = 6");
		System.out.println("2 * 4 = 8");
		System.out.println("2 * 5 = 10");
		System.out.println("2 * 6 = 12");
		System.out.println("2 * 7 = 14");
		System.out.println("2 * 8 = 16");
		System.out.println("2 * 9 = 18");
		System.out.println("==========================");
		System.out.println("< " + dan + "단 >");
		for(int i=1; i<=9; i++) {
			System.out.println(dan +" * " + i + " = "+ (dan*i));
			
		}
		System.out.println("==========================");
		
		System.out.println("< " + dan + "단 >");
		for(int i=1; i<=9; i++) {
			System.out.println(dan+" * " + i + " = "+(dan*i));
		}
		
		
		
		
		
		
		
		
		
		
	}

}
