package interface_statement;

public interface MyInterface2 {

}
