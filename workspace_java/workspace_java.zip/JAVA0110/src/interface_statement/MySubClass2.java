package interface_statement;

public class MySubClass2 implements MyInterface2 {

}
