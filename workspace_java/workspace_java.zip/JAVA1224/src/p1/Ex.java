package p1;	// 현재 클래스가 소속된 패키지는 package 키워드 뒤에 표기(필수!)
//=> 만약, p1 이름 대신 다른 이름을 지정하거나 package문이 생략될 경우 오류 발생함
public class Ex {
	// => p2 패키지의 Ex클래스와 클래스명은 동일하지만 패키지가 다르므로 중복가능
	public static void main(String[] args) {

	}

}
